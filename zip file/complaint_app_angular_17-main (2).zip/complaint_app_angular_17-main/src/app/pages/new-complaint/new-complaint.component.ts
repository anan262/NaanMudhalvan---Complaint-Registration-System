import { Component } from '@angular/core';

@Component({
  selector: 'app-new-complaint',
  standalone: true,
  imports: [],
  templateUrl: './new-complaint.component.html',
  styleUrl: './new-complaint.component.css'
})
export class NewComplaintComponent {

}
