import { Component } from '@angular/core';

@Component({
  selector: 'app-complaint-list',
  standalone: true,
  imports: [],
  templateUrl: './complaint-list.component.html',
  styleUrl: './complaint-list.component.css'
})
export class ComplaintListComponent {

}
